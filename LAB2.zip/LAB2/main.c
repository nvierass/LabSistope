#include <unistd.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include "cabeza.h"

int main(int argc,char** argv){   
	srand(time(NULL));
    //manejo de getopt
    cantFotones = 0;
    maxDist = 0;
    int ejeX = 0;
    int ejeY = 0;
    double delta = 0;
    bflag = 0;
    opterr = 0;
    int c;
    
    while((c = getopt(argc,argv, "n:L:X:Y:d:b")) != -1){
        switch(c){
            case 'n':
                sscanf(optarg,"%d", &cantFotones);
                break;
        	case 'L':
                sscanf(optarg,"%d", &maxDist);
                break;
            case 'X':
                sscanf(optarg,"%d", &ejeX);
                break;
        	case 'Y':
                sscanf(optarg,"%d", &ejeY);
                break;
            case 'd':
                sscanf(optarg,"%lf", &delta);
                break;
            case 'b':
                bflag = 1;
                break;
            case '?':
		        if (optopt == 'n')
		          fprintf (stderr, "Debe indicar un valor para -%c.\n", optopt);
		        else if (optopt == 'L')
		          fprintf (stderr, "Debe indicar un valor para -%c.\n", optopt);
		        else if (optopt == 'X')
		          fprintf (stderr, "Debe indicar un valor para -%c.\n", optopt);
		        else if (optopt == 'Y')
		          fprintf (stderr, "Debe indicar un valor para -%c.\n", optopt);
		        else if (optopt == 'd')
		          fprintf (stderr, "Debe indicar un valor para -%c.\n", optopt);
		        //else if (isprint (optopt))
		        //  fprintf (stderr, "Unknown option `-%c'.\n", optopt);
		        return 1;
		    default:
                abort();
        }
    }
    inicializarGrilla(ejeX,ejeY,delta);
    inicializarFotones();
    salida();
    return 0;
    // -n 10 -L 5 -X 6 -Y 8 -d 1 -b
}
