#include <unistd.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>

typedef struct{
	pthread_mutex_t mutex;
	int energia;
	int X;
	int Y;
}Cuadrante;

typedef struct{
	double ejeX;
	double ejeY;
	double delta;
	Cuadrante ***cuadrante;
}Grilla;

typedef struct{
	double posX;
	double posY;
	double x_Delta;
	double y_Delta;
	double distanciaRecorrida;
	int* cuadrante;
}Foton;

typedef struct{
	double vec_i;
	double vec_j;
}VectorUnitario;

void lanzarFoton();

Grilla *g;
int maxDist;
int cantFotones;
int bflag;

Cuadrante* inicializarCuadrante(int i,int j){
	Cuadrante* nuevo = (Cuadrante*) malloc(sizeof(Cuadrante));
	if(!nuevo){
		return NULL;
	}
	nuevo->energia = 0;
	nuevo->X = i;
	nuevo->Y = j;
	pthread_mutex_init(&(nuevo->mutex),NULL);
	return nuevo;
}

void inicializarGrilla(double ejeX, double ejeY, double delta){
	int i,j;
	g = (Grilla*)malloc(sizeof(Grilla));
	g->ejeX = ejeX;
	g->ejeY = ejeY;
	g->delta = delta;
	g->cuadrante = (Cuadrante***)malloc(sizeof(Cuadrante**)*g->ejeX);
	for(i=0;i<g->ejeX;i++)
	{
		g->cuadrante[i] = (Cuadrante**)malloc(sizeof(Cuadrante*)*g->ejeY);
	}
	for(i=0;i<g->ejeX;i++)
	{
		for(j=0;j<g->ejeY;j++)
		{
			g->cuadrante[i][j] = inicializarCuadrante(i,j);
		}
	}
}

void inicializarFotones(){
	int i;
	pthread_t fotones[cantFotones];
	for(i=0;i<cantFotones;i++)
	{
		pthread_create(&fotones[i],NULL,(void*)lanzarFoton,NULL);
	}
	for(i=0;i<cantFotones;i++)
	{
		pthread_join(fotones[i],NULL);
	}
}

int *calcularCuadrante(double x_Delta, double y_Delta){
	int *par = (int*)malloc(sizeof(int)*2);
	//par[0]=-1;
	//par[1]=-1;
	double max_delta = (g->ejeX/2)*g->delta;
	double min_delta = max_delta*-1;
	double aux = min_delta + g->delta;
	int i;
	for(i=0;i<g->ejeX;i++){
		if( min_delta < x_Delta && x_Delta <= aux){
			par[0] = i;		
		}
		min_delta+= g->delta;
		aux += g->delta;
	}
	max_delta = (g->ejeY/2)*g->delta;
	min_delta = max_delta*-1;
	aux = min_delta + g->delta;
	for(i=0;i<g->ejeY;i++){
		if( min_delta < y_Delta && y_Delta <= aux){
			par[1] = i;		
		}
		min_delta+= g->delta;
		aux += g->delta;
	}
	return par;
}

Foton *crearFoton(){
	Foton *f = (Foton*)malloc(sizeof(Foton));
	f->posX = g->ejeX/2;
	f->posY = g->ejeY/2;
	f->x_Delta = 0;
	f->y_Delta = 0;
	f->distanciaRecorrida = 0;
	f->cuadrante = calcularCuadrante(f->x_Delta, f->y_Delta);
	return f;
}

double randomSign(double n){
	int x = rand()%100;
	if (x>=50){
		return -n;
	}
	return n;
}

VectorUnitario generarVector(){
	double x = (rand()%100)/100.0;
	x = randomSign(x);
	double n = 1-x*x;
	double y = sqrt(n);
	y = randomSign(y);
	VectorUnitario res;
	res.vec_i = x;
	res.vec_j = y;
	return res;
}

void lanzarFoton(){
	double r,l;
	int* cuadrante_Nuevo;
	int aux;
	double x_Delta, y_Delta;
	VectorUnitario director;
	Foton *f = crearFoton();
	while(f->distanciaRecorrida < maxDist)
	{
		r = (rand()%100)/100.0;
		l = -log(1-r);
		director = generarVector();
		while(director.vec_i == 0 || director.vec_j==0){
			director = generarVector();
		}
		f->distanciaRecorrida+=	l;
		x_Delta = f->distanciaRecorrida*director.vec_i;
		y_Delta = f->distanciaRecorrida*director.vec_j;
		cuadrante_Nuevo = calcularCuadrante(x_Delta,y_Delta);
		//Comprobar si el cuadrante esta ocupado
		pthread_mutex_lock(&g->cuadrante[cuadrante_Nuevo[0]][cuadrante_Nuevo[1]]->mutex);
		//Una vez desocupado el cuadrante nuevo.
		//lockear
		f->x_Delta = x_Delta;
		f->y_Delta = y_Delta;
		free(f->cuadrante);
		f->cuadrante = cuadrante_Nuevo;
		//Selección del proceso
		aux = rand()%100;
		//Para la absorcion se suma 1 a y vuelve a entrar al while, si no es absorcion simplemente vuelve a repetir para moverse.
		if(aux>=50){g->cuadrante[cuadrante_Nuevo[0]][cuadrante_Nuevo[1]]->energia++;}
		//Unlock cuadrante
		pthread_mutex_unlock(&g->cuadrante[cuadrante_Nuevo[0]][cuadrante_Nuevo[1]]->mutex);
	}

}

void salida(){
	FILE *salida = fopen("salida.txt","w");
	int i,j;
	for(i=0;i<g->ejeX;i++){
		for(j=0;j<g->ejeY;j++){
			fprintf(salida,"< %d [%d][%d] >\n",g->cuadrante[i][j]->energia, i,j);
		}
	}
	fclose(salida);
}

int main(int argc,char** argv){   
	srand(time(NULL));
    //manejo de getopt
    cantFotones = 0;
    maxDist = 0;
    int ejeX = 0;
    int ejeY = 0;
    double delta = 0;
    bflag = 0;
    opterr = 0;
    int c;
    
    while((c = getopt(argc,argv, "n:L:X:Y:d:b")) != -1){
        switch(c){
            case 'n':
                sscanf(optarg,"%d", &cantFotones);
                break;
        	case 'L':
                sscanf(optarg,"%d", &maxDist);
                break;
            case 'X':
                sscanf(optarg,"%d", &ejeX);
                break;
        	case 'Y':
                sscanf(optarg,"%d", &ejeY);
                break;
            case 'd':
                sscanf(optarg,"%lf", &delta);
                break;
            case 'b':
                bflag = 1;
                break;
            case '?':
		        if (optopt == 'n')
		          fprintf (stderr, "Debe indicar un valor para -%c.\n", optopt);
		        else if (optopt == 'L')
		          fprintf (stderr, "Debe indicar un valor para -%c.\n", optopt);
		        else if (optopt == 'X')
		          fprintf (stderr, "Debe indicar un valor para -%c.\n", optopt);
		        else if (optopt == 'Y')
		          fprintf (stderr, "Debe indicar un valor para -%c.\n", optopt);
		        else if (optopt == 'd')
		          fprintf (stderr, "Debe indicar un valor para -%c.\n", optopt);
		        //else if (isprint (optopt))
		        //  fprintf (stderr, "Unknown option `-%c'.\n", optopt);
		        return 1;
		    default:
                abort();
        }
    }
    inicializarGrilla(ejeX,ejeY,delta);
    inicializarFotones();
    salida();
    return 0;
    // -n 10 -L 5 -X 6 -Y 8 -d 1 -b
}
