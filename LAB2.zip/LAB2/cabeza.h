#ifndef __CABEZA__
#define __CABEZA__

//ESTRUCTURAS

typedef struct{
	pthread_mutex_t mutex;
	int energia;
	int X;
	int Y;
}Cuadrante;

typedef struct{
	double ejeX;
	double ejeY;
	double delta;
	Cuadrante ***cuadrante;
}Grilla;

typedef struct{
	double posX;
	double posY;
	double x_Delta;
	double y_Delta;
	double distanciaRecorrida;
	int* cuadrante;
}Foton;

typedef struct{
	double vec_i;
	double vec_j;
}VectorUnitario;

Grilla *g;
int maxDist;
int cantFotones;
int bflag;

//FUNCIONES

Cuadrante* inicializarCuadrante(int i,int j);
void inicializarGrilla(double ejeX, double ejeY, double delta);
void inicializarFotones();
int *calcularCuadrante(double x_Delta, double y_Delta);
Foton *crearFoton();
double randomSign(double n);
VectorUnitario generarVector();
void lanzarFoton();
void salida();

#endif
