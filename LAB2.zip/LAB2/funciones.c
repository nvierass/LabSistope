#ifndef funciones_c
#define funciones_c
#include <unistd.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include "cabeza.h"





//Esta funcion asigna memoria e inicializa al cuadrante de la grilla cuya posicion corresponde a los valores de i y j
Cuadrante* inicializarCuadrante(int i,int j){
	Cuadrante* nuevo = (Cuadrante*) malloc(sizeof(Cuadrante));
	if(!nuevo){
		return NULL;
	}
	nuevo->energia = 0;
	nuevo->X = i;
	nuevo->Y = j;
	pthread_mutex_init(&(nuevo->mutex),NULL);
	return nuevo;
}

//Esta funcion asigna memoria e inicializa la grilla dados los parametros ingresados por el usuario
void inicializarGrilla(double ejeX, double ejeY, double delta){
	int i,j;
	g = (Grilla*)malloc(sizeof(Grilla));
	g->ejeX = ejeX;
	g->ejeY = ejeY;
	g->delta = delta;
	g->cuadrante = (Cuadrante***)malloc(sizeof(Cuadrante**)*g->ejeX);
	for(i=0;i<g->ejeX;i++)
	{
		g->cuadrante[i] = (Cuadrante**)malloc(sizeof(Cuadrante*)*g->ejeY);
	}
	for(i=0;i<g->ejeX;i++)
	{
		for(j=0;j<g->ejeY;j++)
		{
			g->cuadrante[i][j] = inicializarCuadrante(i,j);
		}
	}
}

//Esta funcion inicializa los fotones como threads en la funcion lanzarFoton para que comiencen su ejecucion
//luego el thread correspondiente al main espera a que todos los thread finalicen la ejecucion de lanzarFoton
void inicializarFotones(){
	int i;
	pthread_t fotones[cantFotones];
	for(i=0;i<cantFotones;i++)
	{
		pthread_create(&fotones[i],NULL,(void*)lanzarFoton,NULL);
	}
	for(i=0;i<cantFotones;i++)
	{
		pthread_join(fotones[i],NULL);
	}
}
 
//Esta funcion calcula la posicion que le corresponde en la grilla dados el movimiento entregado como parametros x_Delta e y_Delta
int *calcularCuadrante(double x_Delta, double y_Delta){
	int *par = (int*)malloc(sizeof(int)*2);
	//par[0]=-1;
	//par[1]=-1;
	double max_delta = (g->ejeX/2)*g->delta;
	double min_delta = max_delta*-1;
	double aux = min_delta + g->delta;
	if(x_Delta <= min_delta || x_Delta >=max_delta){
		free(par);
		return NULL;	
	}
	int i;
	for(i=0;i<g->ejeX;i++){
		if( min_delta < x_Delta && x_Delta <= aux){
			par[0] = i;		
		}
		min_delta+= g->delta;
		aux += g->delta;
	}
	max_delta = (g->ejeY/2)*g->delta;
	min_delta = max_delta*-1;
	aux = min_delta + g->delta;
	if(y_Delta <= min_delta || y_Delta >=max_delta){
		free(par);
		return NULL;	
	}
	for(i=0;i<g->ejeY;i++){
		if( min_delta < y_Delta && y_Delta <= aux){
			par[1] = i;		
		}
		min_delta+= g->delta;
		aux += g->delta;
	}
	return par;
}

//Esta funcion iniciliza el foton en el centro de la grilla
Foton *crearFoton(){
	Foton *f = (Foton*)malloc(sizeof(Foton));
	f->posX = g->ejeX/2;
	f->posY = g->ejeY/2;
	f->x_Delta = 0;
	f->y_Delta = 0;
	f->distanciaRecorrida = 0;
	f->cuadrante = calcularCuadrante(f->x_Delta, f->y_Delta);
	return f;
}

//Esta funcion obtiene 
double randomSign(double n){
	int x = rand()%100;
	if (x>=50){
		return -n;
	}
	return n;
}

VectorUnitario generarVector(){
	double x = (rand()%100)/100.0;
	x = randomSign(x);
	double n = 1-x*x;
	double y = sqrt(n);
	y = randomSign(y);
	VectorUnitario res;
	res.vec_i = x;
	res.vec_j = y;
	return res;
}

void lanzarFoton(){
	double r,l;
	int* cuadrante_Nuevo;
	int aux;
	double x_Delta, y_Delta;
	VectorUnitario director;
	Foton *f = crearFoton();
	while(f->distanciaRecorrida < maxDist)
	{
		r = (rand()%100)/100.0;
		l = -log(1-r);
		director = generarVector();
		while(director.vec_i == 0 || director.vec_j==0){
			director = generarVector();
		}
		f->distanciaRecorrida+=	l;
		x_Delta = f->distanciaRecorrida*director.vec_i;
		y_Delta = f->distanciaRecorrida*director.vec_j;
		cuadrante_Nuevo = calcularCuadrante(x_Delta,y_Delta);
		if(!cuadrante_Nuevo){
			break;
		}
		//Comprobar si el cuadrante esta ocupado
		pthread_mutex_lock(&g->cuadrante[cuadrante_Nuevo[0]][cuadrante_Nuevo[1]]->mutex);
		
		//lock
		//Una vez desocupado el cuadrante nuevo.
		if(bflag){
			printf("Una hebra ha ingresado a la sección critica\n");
			printf("El foton se movera de la posición (%f,%f) a la posición (%f,%f), cuadrante nuevo: %d%d\n",f->x_Delta,f->y_Delta,x_Delta,y_Delta,cuadrante_Nuevo[0],cuadrante_Nuevo[1]);
		}
		f->x_Delta = x_Delta;
		f->y_Delta = y_Delta;
		free(f->cuadrante);
		f->cuadrante = cuadrante_Nuevo;
		//Selección del proceso
		aux = rand()%100;
		//Para la absorcion se suma 1 a y vuelve a entrar al while, si no es absorcion simplemente vuelve a repetir para moverse.
		if(aux>=50){
			g->cuadrante[cuadrante_Nuevo[0]][cuadrante_Nuevo[1]]->energia++;
			if(bflag){
				printf("Se ha realizado la absorción\n");			
			}
		}
		else{
			if(bflag){
				printf("Se ha realizado la difusión\n");	
			}
		}
		if(bflag){
			printf("Se ha liberado la sección critica\n");	
			}
		//Unlock cuadrante
		pthread_mutex_unlock(&g->cuadrante[cuadrante_Nuevo[0]][cuadrante_Nuevo[1]]->mutex);
	}

}

void salida(){
	FILE *salida = fopen("salida.txt","w");
	int i,j;
	for(i=0;i<g->ejeX;i++){
		for(j=0;j<g->ejeY;j++){
			fprintf(salida,"< %d [%d][%d] >\n",g->cuadrante[i][j]->energia, i,j);
		}
	}
	fclose(salida);
}

#endif
