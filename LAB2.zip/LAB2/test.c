

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

typedef struct{
	double vec_i;
	double vec_j;
} VectorUnitario;

int X = 6;
int Y = 8;
double delta = 1;

int *calcularCuadrante(double x_Delta, double y_Delta){
	double max_delta = (X/2)*delta;
	double min_delta = max_delta*-1;
	double aux = min_delta + delta;
	int i;
	for(i=0;i<X;i++){
		if( min_delta < x_Delta && x_Delta <= aux){
			par[0] = i;		
		}
		min_delta+= delta;
		aux += delta;
	}
	max_delta = (Y/2)*delta;
	min_delta = max_delta*-1;
	aux = min_delta + delta;
	for(i=0;i<Y;i++){
		if( min_delta < y_Delta && y_Delta <= aux){
			par[1] = i;		
		}
		min_delta+= delta;
		aux += delta;
	}
	return par;
}

double randomSign(double n){
	int x = rand()%100;
	if (x>=50){
		return -n;
	}
	return n;
}

VectorUnitario generarVector(){
	double x = (rand()%100)/100.0;
	x = randomSign(x);
	double n = 1-x*x;
	double y = sqrt(n);
	y = randomSign(y);
	VectorUnitario res;
	res.vec_i = x;
	res.vec_j = y;
	return res;
}

void main(){
	srand(time(NULL));
	int* x = calcularCuadrante(-2.5,-3.5); 
	printf("Valores del cuadrantei: %i j: %i \n", x[0],x[1]);
	printf("------------------------------------------\n");
	int* y = calcularCuadrante(1.5,2.5); 
	printf("Valores del cuadrantei: %i j: %i \n", y[0],y[1]);
printf("------------------------------------------\n");
	int* t = calcularCuadrante(0.5,-0.5);  
	printf("Valores del cuadrantei: %i j: %i \n", t[0],t[1]);
printf("------------------------------------------\n");
	 int* z = calcularCuadrante(-1.5,1.5); 
	printf("Valores del cuadrantei: %i j: %i \n", z[0],z[1]);

}
